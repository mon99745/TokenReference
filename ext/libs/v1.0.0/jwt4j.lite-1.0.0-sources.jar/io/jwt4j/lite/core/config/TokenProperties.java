package io.jwt4j.lite.core.config;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;


/**
 * 토큰 검증 관리
 */
@Data
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@ConfigurationProperties(prefix = TokenProperties.PROPERTY_PREFIX)
public class TokenProperties {
	/**
	 * 설정 타이틀
	 */
	public static final String PROPERTY_PREFIX = "token.info";

	/**
	 * 설정 정보
	 */
	@Getter
	private static TokenProperties instance = new TokenProperties();

	/**
	 * 라이브러리명
	 */
	private static final String name = "JWT4J";

	/**
	 * 키 페어 경로
	 */
	protected String path = "./files/";

	/**
	 * 키 페어 크기
	 */
	protected int keySize = 2048;

	/**
	 * 토큰 타입
	 */
	protected String typ = "jsonwebtoken";

	/**
	 * 토큰 만료 시간 (기본: 1시간)
	 */
	protected long exp = 60 * 60 * 1000L;

	/**
	 * 토큰 암호화 알고리즘
	 */
	protected String alg = "RSA";

	/**
	 * 토큰 발급자
	 */
	protected String iss = "jwt4j-core";

	/**
	 * 토큰 주제
	 */
	protected String sub = "jwt4j-lite";
}